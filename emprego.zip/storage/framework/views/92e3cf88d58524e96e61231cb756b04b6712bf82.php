<?php $__env->startSection('content'); ?>
	<section class="container" role="main">

    	<div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">FALE CONOSCO</h1>
            </header>
            <div class="row sobre_conteudo">
                <div class="col-md-6 sobre_contTexto hidden-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                </div>
               <?php echo Form::open(['url' => 'enviarEmail', 'action' => 'EmailController@enviar']); ?>

                <div class="col-md-6 sobre_contTexto visible-lg">
                    <p>Seu nome:  <?php echo Form::text('nome', null,  array('required', 'class'=>'form-control',  'placeholder'=>'Digite seu nome')); ?></p>
                    <p>Seu e-mail: <?php echo Form::text('email', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite seu e-mail')); ?></p>
                    <p>Assunto: <?php echo Form::text('assunto', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite um assunto para sua mensagem')); ?></p>
                    <p>Mensagem:  <?php echo Form::textarea('mensagem', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite sua mensagem')); ?></p>
							<div class="text-left">

									<?php echo Form::submit('ENVIAR',
		array('class'=>'btn btn-default sobre_btn_enviar')); ?>

							</div>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="<?php echo asset("assets/img/foto_laboratorio.jpg"); ?>" class="img-responsive" alt="Foto do Fale Conosco">
                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>