<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	<div class="noticia_conteudo col-lg-12 col-md-12">
    		<h1><?php echo $noticia->titulo; ?></h1>
    		<a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $noticia->categoria->linkCategoria; ?>/<?php echo $noticia->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $noticia->categoria->descricao; ?></button></a>
    		<h2>Publicado em <?php echo date('d/m/Y', strtotime($noticia->data_pub)); ?></h2>
				<span style="max-width: 500px; float: left;     margin: 10px;">      	<img src="../../../../painel/fotos/noticias/<?php echo $noticia->foto; ?>" class="img-responsive center-block" alt="Foto da notícia <?php echo $noticia->titulo; ?>"></span>
	        <p> <?php echo $noticia->descricao; ?></p>


    	</div>
    	<div class="outras_noticias col-md-12">

            <?php foreach($noticiasRelacionadas as $item): ?>
    		<div class="noticia col-md-4">

            		  <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
            		  <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit nulla eu dictum nisl...</p></a>
    		</div>

    		   <?php endforeach; ?>
    	</div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>