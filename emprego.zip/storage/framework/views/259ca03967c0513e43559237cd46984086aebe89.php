<?php $__env->startSection('body'); ?>
           <!-- Modal -->
	<div class="modal fade" id="MaisNoticias" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">NOTÍCIAS</h1>
				</div>
				<div class="modal-body">
					<div class="noticias_modal">
	                    <button class="btn btn-default" type="submit">CATEGORIA</button>
	                    <div class="noticias_link">
	                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
	                        <a href="noticia.html"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
	                    </div>
                	</div>
                	<div class="noticias_modal">
	                    <button class="btn btn-default" type="submit">CATEGORIA</button>
	                    <div class="noticias_link">
	                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
	                        <a href="noticia.html"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
	                    </div>
                	</div>
                	<div class="noticias_modal">
	                    <button class="btn btn-default" type="submit">CATEGORIA</button>
	                    <div class="noticias_link">
	                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
	                        <a href="noticia.html"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
	                    </div>
                	</div>
				</div>
				<div class="modal-footer">
					<ul class="pager">
						<li class="previous"><a href="#"><span aria-hidden="true">&larr;</span> MAIS ANTIGAS</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
           <!-- objeto header-->
    <section class="container" role="main">
        <div class="noticias">
            <header class="row">
                <h1 class="col-md-12 text-center">NOTÍCIAS</h1>
            </header>
            <div class="row">
                <div class="col-md-6 col-sm-6 noticias_principal">
                    <button class="btn btn-default" type="submit">CATEGORIA</button>
                    <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                        <span class="dia">21</span>
                        <span class="mes_ano"><p>NOV<br/>2015</p></span>
                    </div>
                    <div class="noticias_link">
                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
                        <a href="noticia.html" class="hidden-sm hidden-xs"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
                        <a href="noticia.html" class="visible-xs"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus...</p></a>
                        <a href="noticia.html" class="visible-sm"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>   
            		</div>
                </div>
                <div class="col-md-6 col-sm-6 noticias_secundaria noticias_secundariaUm">
                    <button class="btn btn-default" type="submit">CATEGORIA</button>
                    <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                        <span class="dia">21</span>
                        <span class="mes_ano"><p>NOV<br/>2015</p></span>
                    </div>
                    <div class="noticias_link">
                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
                        <a href="noticia.html" class="visible-xs"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus...</p></a>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 noticias_secundaria noticias_secundariaDois">
                    <button class="btn btn-default" type="submit">CATEGORIA</button>
                    <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                        <span class="dia">21</span>
                        <span class="mes_ano"><p>NOV<br/>2015</p></span>
                    </div>
                    <div class="noticias_link">
                        <a href="noticia.html"><h1>UM TÍTULO PARA ESTA NOTÍCIA</h1></a>
                        <a href="noticia.html" class="visible-xs hidden-sm"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus...</p></a>
                    </div>
                </div>
                <div class="text-right">
                    <button type="button" class="btn btn-default noticias_btn_saibamais notop" data-toggle="modal" data-target="#MaisNoticias">MAIS NOTÍCIAS</button>
                </div>
            </div>
        </div>
    </section>
    <section class="container">
        <div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">SOBRE</h1>
            </header>
            <div class="row sobre_conteudo">
                <div class="col-md-6 sobre_contTexto hidden-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                </div>
                <div class="col-md-6 sobre_contTexto visible-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Quisque venenatis, risus sed vulputate congue.</p>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="img/foto_fatecbb.jpg" class="img-responsive" alt="Foto do Campus da Fatec Bebedouro">
                </div>
                <div class="text-right">
                    <a class="btn btn-default sobre_btn_saibamais" href="#" role="button">SAIBA MAIS</a>
                </div>
            </div>
        </div>
    </section>
               
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plane', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>