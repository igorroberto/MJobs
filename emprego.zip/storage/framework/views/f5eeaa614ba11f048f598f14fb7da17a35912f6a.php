<!DOCTYPE html>
    <html lang="pt-br">
      <head>
        <meta charset="utf-8">
      </head>
      <body>
        <h2>Dados do contato</h2>
        <p>Nome: <?php echo e($nome); ?></p>
        <p>E-mail: <?php echo e($email); ?></p>
        <p>Assunto: <?php echo e($assunto); ?></p>
         <p>Mensagem: <?php echo e($mensagem); ?></p>
      </body>
    </html>
  