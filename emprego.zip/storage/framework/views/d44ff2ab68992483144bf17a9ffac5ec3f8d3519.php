
<?php $__env->startSection('content'); ?>
	<!-- Modal -->
	 <?php  $f=0;  $j=0; ?>
     <?php for($i=0; $i < count($noticias); $i++): ?>
 <?php
                                       
                                       if($i == 0){
                                       
                                       $item = $noticias[$i];
                                       }elseif($i > 0 && $i <=2 ){
                                                              
                                        $noticiaSub[$f] = $noticias[$i];
                                       $f++;
                                       }elseif($i > 2 && $i <= 5){
                                                            
                                        $noticiaModal[$j] = $noticias[$i];
                                      $j++;
                                       }
                                       ?>
<?php endfor; ?>

    <section class="container" role="main">
        <div class="noticias">
            <header class="row">
                <h1 class="col-md-12 text-center">NOTÍCIAS</h1>
            </header>
            <div class="row">
                <div class="col-md-6 col-sm-6 noticias_principal">
                    	<a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
                    <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                        <span class="dia">21</span>
                        <span class="mes_ano"><p>NOV<br/>2015</p></span>
                    </div>
                    <div class="noticias_link">
                       <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
                        <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
                        <a href="noticia.html" class="visible-xs"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus...</p></a>
                        <a href="noticia.html" class="visible-sm"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>   
            		</div>
                </div>
                <div class="modal fade" id="MaisNoticias" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">NOTÍCIAS</h1>
				</div>
				<div class="modal-body">
               
                     <?php foreach($noticiaModal as $item): ?>
                    
      
               
                      <div class="noticias_modal">
	                <a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
	                    <div class="noticias_link">
	                     <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
	                       <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
	                    </div>
                	</div>
                 
                     <?php endforeach; ?>
				</div> 
					
                	
                   
				<div class="modal-footer">
					<ul class="pager">
						<li class="previous"><a href="<?php echo URL::to('/noticia/noticias/');; ?>"><span aria-hidden="true">&larr;</span> MAIS ANTIGAS</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
                 <?php foreach($noticiaSub as $item): ?>
           

                       <div class="col-md-6 col-sm-6 noticias_secundaria noticias_secundariaUm">
                           <a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
                            <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                                <span class="dia">21</span>
                                <span class="mes_ano"><p>NOV<br/>2015</p></span>
                            </div>
                            <div class="noticias_link">
                                <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
                               
                            </div>
                        </div>
                <?php endforeach; ?>
               
               
                <div class="text-right">
                    <button type="button" class="btn btn-default noticias_btn_saibamais notop" data-toggle="modal" data-target="#MaisNoticias">MAIS NOTÍCIAS</button>
                </div>
            </div>
        </div>
    </section>
    <section class="container">
        <div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">SOBRE</h1>
            </header>
            <div class="row sobre_conteudo">
                <div class="col-md-6 sobre_contTexto hidden-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                </div>
                <div class="col-md-6 sobre_contTexto visible-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Quisque venenatis, risus sed vulputate congue.</p>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="<?php echo asset("assets/img/sobrenos.jpg"); ?>" class="img-responsive" alt="Foto do Campus da Fatec Bebedouro">
                </div>
                <div class="text-right">
                    <a class="btn btn-default sobre_btn_saibamais" href="#" role="button">SAIBA MAIS</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>