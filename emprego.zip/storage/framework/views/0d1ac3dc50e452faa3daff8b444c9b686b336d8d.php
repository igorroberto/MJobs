
<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	
    	<div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">SOBRE</h1>
            </header>
            <div class="row sobre_conteudo">
                <div class="col-md-6 sobre_contTexto hidden-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                </div>
                <div class="col-md-6 sobre_contTexto visible-lg">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam molestie et justo ac ornare. Fusce nec viverra sem, eu pharetra neque. Vestibulum consectetur gravida purus sed luctus. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur.</p>
                    <p>Donec luctus tortor porta ligula blandit luctus. Quisque venenatis, risus sed vulputate congue, elit ligula tincidunt massa, ac efficitur erat ipsum at eros. Curabitur nec pharetra augue, eu feugiat diam. Fusce ut turpis id mauris posuere porttitor. Vestibulum fringilla elit et dignissim efficitur. Fusce sed dignissim est, et vulputate neque. Curabitur maximus finibus blandit. Nulla non egestas quam. Quisque venenatis, risus sed vulputate congue.</p>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="img/foto_fatecbb.jpg" class="img-responsive" alt="Foto do Campus da Fatec Bebedouro">
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>