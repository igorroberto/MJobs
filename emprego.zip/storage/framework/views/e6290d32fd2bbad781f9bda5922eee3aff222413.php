<?php $__env->startSection('content'); ?>
	<section>
  <div class="container">
    <h3>Créditos</h3>

    <p>
      Este site da <strong>Faculdade de Tecnologia de Taquaritinga</strong> iniciou como um projeto de pesquisa do
      <a href="//gpes.fatectq.edu.br" target="_blank">GPES</a>, por meio de sua coordenadora <b>Profa. Dra. Daniela Gibertoni</b>, realizando primeiramente avaliações no site anterior, constatando-se assim a necessidade de elaboração de um novo site.
    </p>

    <p>
      Após as avaliações, os alunos de iniciação científica do GPES iniciaram a construção dos protótipos das páginas e a elaboração da arquitetura de informação.
    </p>

    <p>
      Com o início da implementação, professores colaboradores foram convidados a participar diretamente da construção do site. O <b>Prof. Me. Erick Petrucelli</b> contribuiu com desenvolvimento <i>front-end</i> e <i>back-end</i> e o <b>Prof. Esp. Diogo Almeida</b> contribuiu com a infraestrutura de <i>hardware</i>.
    </p>

    <hr />

    <h4>Grupo de Pesquisa em Engenharia de Software</h4>

    <div class="media card">
      <img src="//arquivos.biblioceeteps.com.br/p/daniela.gibertoni.jpg?v=20131128152148&amp;h=70" alt="Foto do docente" class="img-thumbnail media-object pull-left" />

      <div class="media-body">
        <h5 class="media-heading">Daniela Gibertoni</h5>

        <span class="text-muted">Doutora em Engenharia de Produção</span>
        <small class="separator">●</small>
        <span class="text-muted">Professor de Ensino Superior III - C</span>

        <br />

        <span>
          <i class="glyphicon glyphicon-envelope"></i>
          <a href="mailto:daniela.gibertoni@fatectq.edu.br">daniela.gibertoni@fatectq.edu.br</a>
        </span>

        <small class="separator">●</small>

        <span>
          <i class="glyphicon glyphicon-globe"></i>
          <a href="//lattes.cnpq.br/6253249405332428" target="_blank">Acessar currículo Lattes</a>
        </span>
      </div>
    </div>

    <div class="media">
      <div class="media card col-md-6">
        <img src="//arquivos.biblioceeteps.com.br/p/211214351.jpg?v=20131128152148&amp;h=70" alt="Foto do discente" class="img-thumbnail media-object pull-left" />

        <div class="media-body">
          <h5 class="media-heading">Thaís Cristina Casagrande</h5>

          <span class="text-muted">Análise e Desenvolvimento de Sistemas</span>
          <small class="separator">●</small>
          <span class="text-muted">Noite</span>

          <br />

          <span>
            <i class="glyphicon glyphicon-envelope"></i>
            <a href="mailto:thais.casagrande@fatectq.edu.br">thais.casagrande@fatectq.edu.br</a>
          </span>
        </div>
      </div>

      <div class="media card col-md-6">
        <img src="//arquivos.biblioceeteps.com.br/p/211113170.jpg?v=20131128152148&amp;h=70" alt="Foto do discente" class="img-thumbnail media-object pull-left" />

        <div class="media-body">
          <h5 class="media-heading">Fabian Venturini Cabal</h5>

          <span class="text-muted">Análise e Desenvolvimento de Sistemas</span>
          <small class="separator">●</small>
          <span class="text-muted">Tarde</span>

          <br />

          <span>
            <i class="glyphicon glyphicon-envelope"></i>
            <a href="mailto:fabiancabal@hotmail.com">fabiancabal@hotmail.com</a>
          </span>
        </div>
      </div>

      <div class="media card col-md-6">
        <img src="//arquivos.biblioceeteps.com.br/p/211113200.jpg?v=20131128152148&amp;h=70" alt="Foto do discente" class="img-thumbnail media-object pull-left" />

        <div class="media-body">
          <h5 class="media-heading">Renato Scache Fabri</h5>

          <span class="text-muted">Análise e Desenvolvimento de Sistemas</span>
          <small class="separator">●</small>
          <span class="text-muted">Tarde</span>

          <br />

          <span>
            <i class="glyphicon glyphicon-envelope"></i>
            <a href="mailto:renato_sfabri@hotmail.com">renato_sfabri@hotmail.com</a>
          </span>
        </div>
      </div>

      <div class="media card col-md-6">
        <img src="//arquivos.biblioceeteps.com.br/p/211214384.jpg?v=20131128152148&amp;h=70" alt="Foto do discente" class="img-thumbnail media-object pull-left" />

        <div class="media-body">
          <h5 class="media-heading">Jean Carlos Caetano da Costa</h5>

          <span class="text-muted">Análise e Desenvolvimento de Sistemas</span>
          <small class="separator">●</small>
          <span class="text-muted">Noite</span>

          <br />

          <span>
            <i class="glyphicon glyphicon-envelope"></i>
            <a href="mailto:jean_caetaninho@hotmail.com">jean_caetaninho@hotmail.com</a>
          </span>
        </div>
      </div>

      <div class="media card col-md-6">
        <img src="//arquivos.biblioceeteps.com.br/p/211214341.jpg?v=20131128152148&amp;h=70" alt="Foto do discente" class="img-thumbnail media-object pull-left" />

        <div class="media-body">
          <h5 class="media-heading">Paulo Cesar Martins</h5>

          <span class="text-muted">Análise e Desenvolvimento de Sistemas</span>
          <small class="separator">●</small>
          <span class="text-muted">Noite</span>

          <br />

          <span>
            <i class="glyphicon glyphicon-envelope"></i>
            <a href="mailto:paulo_3k@hotmail.com">paulo_3k@hotmail.com</a>
          </span>
        </div>
      </div>
    </div>

    <hr />

    <h4>Professores Colaboradores</h4>

    <div class="media card">
      <img src="//arquivos.biblioceeteps.com.br/p/erick.petrucelli.jpg?v=20131024165731&amp;h=70" alt="Foto do docente" class="img-thumbnail media-object pull-left" />

      <div class="media-body">
        <h5 class="media-heading">Erick Eduardo Petrucelli</h5>

        <span class="text-muted">Mestre em Engenharia de Produção</span>
        <small class="separator">●</small>
        <span class="text-muted">Professor de Ensino Superior II - B</span>

        <br />

        <span>
          <i class="glyphicon glyphicon-envelope"></i>
          <a href="mailto:erick.petrucelli@fatectq.edu.br">erick.petrucelli@fatectq.edu.br</a>
        </span>

        <small class="separator">●</small>

        <span>
          <i class="glyphicon glyphicon-globe"></i>
          <a href="//lattes.cnpq.br/3992716400076530" target="_blank">Acessar currículo Lattes</a>
        </span>
      </div>
    </div>

    <div class="media card">
      <img src="//arquivos.biblioceeteps.com.br/p/diogo.almeida.jpg?v=20131128152148&amp;h=70" alt="Foto do docente" class="img-thumbnail media-object pull-left" />

      <div class="media-body">
        <h5 class="media-heading">Diogo de Almeida</h5>

        <span class="text-muted">Especialista em Gestão e Governança em TI</span>
        <small class="separator">●</small>
        <span class="text-muted">Professor de Ensino Superior I - A</span>

        <br />

        <span>
          <i class="glyphicon glyphicon-envelope"></i>
          <a href="mailto:diogo.almeida@fatectq.edu.br">diogo.almeida@fatectq.edu.br</a>
        </span>

        <small class="separator">●</small>

        <span>
          <i class="glyphicon glyphicon-globe"></i>
          <a href="//lattes.cnpq.br/2184493476478223" target="_blank">Acessar currículo Lattes</a>
        </span>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>