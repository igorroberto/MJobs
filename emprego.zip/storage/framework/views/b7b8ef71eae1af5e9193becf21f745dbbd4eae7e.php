
<?php $__env->startSection('content'); ?>
	<section class="container" role="main">

    	<div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">FALE CONOSCO</h1>
            </header>
            <div class="row sobre_conteudo">
			<?php if(Session::has('message')): ?>
    <div class="alert alert-<?php echo e(Session::get('message-type')); ?> alert-dismissable">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
        <i class="glyphicon glyphicon-<?php echo e(Session::get('message-type') == 'success' ? 'ok' : 'remove'); ?>"></i> <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
               
               <?php echo Form::open(['url' => 'enviarEmail', 'action' => 'EmailController@enviar']); ?>

                <div class="col-md-6 sobre_contTexto">
                    <p>Seu nome:  <?php echo Form::text('nome', null,  array('required', 'class'=>'form-control',  'placeholder'=>'Digite seu nome')); ?></p>
                    <p>Seu e-mail: <?php echo Form::text('email', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite seu e-mail')); ?></p>
                    <p>Assunto: <?php echo Form::text('assunto', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite um assunto para sua mensagem')); ?></p>
                    <p>Mensagem:  <?php echo Form::textarea('mensagem', null,
        array('required',
              'class'=>'form-control',
              'placeholder'=>'Digite sua mensagem')); ?></p>
							<div class="text-left">

									<?php echo Form::submit('ENVIAR',
		array('class'=>'btn btn-default sobre_btn_enviar')); ?>

							</div>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="<?php echo asset("assets/img/foto_laboratorio.jpg"); ?>" class="img-responsive" alt="Foto do Fale Conosco">
                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>