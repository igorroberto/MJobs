<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	
    	<div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">Comissão de implantação</h1>
            </header>
            <div class="row sobre_conteudo">
                
               <div class="col-md-12 sobre_contTexto visible-lg">
                   <h2>Comissão de Implantação</h2>
                    <p>
                A Comissão de Implantação é o órgão de supervisão do ensino, da pesquisa e da extensão de serviços à comunidade da Faculdade, obedecidas às diretrizes gerais da política educacional do Centro Paula Souza, conforme definido no Regimento Unificado das Fatecs.<br>
 
Composição:<br>
 
I – Diretor da Faculdade:<br>
Tania Leme de Almeida<br>
II - Coordenadora de Curso<br>
Curso Superior de Tecnologia em Logística<br>
Professora Claudia Silvana da Costa<br>
III - Representante do Corpo Docente:<br>
Professor Alfredo Colenci Neto<br>
Professora Ana Teresa Colenci<br>
Professor Luiz Rossato<br>
Professor Clóvis Santa Fé Junior<br>
Professora Fernanda Scabio Gonçalves<br>
IV – Representante do Corpo Técnico-Administrativo:<br>
Bruna de Lima Ferreira<br>
V – Representante do Corpo Discente:<br>
Guilherme José Reali Pozzi<br>
VI – Representante da Comunidade Local:<br>
Diretor da Etec Paulino Botelho <br>
Aparecido Sedi Moriwaki</p>
                   
                </div>
               
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>