<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	
    	<div class="sobre">
           
<object class="pdf" data="../calendario/test.pdf" type="application/pdf" internalinstanceid="14" style="min-width: 100%; min-height: 800px;" title="">Seu browser não suporta PDF</object>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>