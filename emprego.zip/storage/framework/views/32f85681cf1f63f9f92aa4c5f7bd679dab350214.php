<?php $__env->startSection('content'); ?>
	<section class="container" role="main">

    	<div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">Diretoria de Serviços</h1>
            </header>
            <div class="row sobre_conteudo">

               <div class="col-md-6 sobre_contTexto visible-lg">
                    <p>Setor responsável por todo processo administrativo através de atividades relativas à admissão, contratação de pessoal, concessão de benefícios, rescisão de contrato, manutenção, zeladoria, conservação de patrimônio, compras e vigilância.</p>
                    <p>Diretora de Serviços Administrativos: Valéria Bernuzzi</p>
                    <p>E-mail: f280adm@cps.sp.gov.br</p>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="<?php echo asset("assets/img/laboratorio2.jpg"); ?>" class="img-responsive" alt="Foto do Campus da Fatec Bebedouro">
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>