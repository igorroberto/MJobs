<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	
    	<div class="outras_noticias col-md-12">
            <?php foreach($monitores as $item): ?>
   
    		<div class="noticia col-md-4">
                <img src="../painel/fotos/monitores/<?php echo $item->foto; ?>" class="img-responsive" style="max-width:  100%; max-height: 150px"><br>
    			 <button class="btn btn-default" type="submit">RA: <?php echo $item->ra; ?></button>
                 <button class="btn btn-default" type="submit">E-mail: <?php echo $item->email; ?></button>
            	<h1><?php echo $item->nomecompleto; ?></h1>
            	<p>Horário de atendimento: <?php echo $item->horarios; ?></p>
                <p>Curso: <?php echo $item->curso->nome_curso; ?></p>
                <p>Diciplina: <?php echo $item->disciplina->nome; ?></p>
    		</div>
    		<?php endforeach; ?>
    	</div>
        <?php echo $monitores->render(); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>