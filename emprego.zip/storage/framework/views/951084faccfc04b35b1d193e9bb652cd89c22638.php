
<?php $__env->startSection('content'); ?>
 <?php $__env->startSection('scripts'); ?>
        <script src="<?php echo asset("assets/scripts/getdocentes.js"); ?>"></script>
    <?php $__env->stopSection(); ?>
	<!-- Modal Matriz Curricular -->
	<div class="modal fade" id="MatrizCurricular" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
                <div class="partes">
                    <div class="parte1">
                        <section id="materias">
                            <ul class="tab1">
                                <li><a class="titulomodal">Matérias</a></li>
                                <li><a href="#Materia1" class="tab1links">Materia 1</a></li>
                                <li><a href="#Materia2" class="tab1links">Materia 2</a></li>
                                <li><a href="#Materia3" class="tab1links">Materia 3</a></li>
                                <li><a href="#Materia4" class="tab1links">Materia 4</a></li>
                                <li><a href="#Materia5" class="tab1links">Materia 5</a></li>
                                <li><a href="#Materia6" class="tab1links">Materia 6</a></li>
                            </ul>
                        </section>
                    </div>
                    <div class="parte2">
                        <section id="semestres">
                            <ul class="tab">
                                <li><a href="#1Semestre" class="tablinks">1º Semestre</a></li>
                                <li><a href="#2Semestre" class="tablinks">2º Semestre</a></li>
                                <li><a href="#3Semestre" class="tablinks">3º Semestre</a></li>
                                <li><a href="#4Semestre" class="tablinks">4º Semestre</a></li>
                                <li><a href="#5Semestre" class="tablinks">5º Semestre</a></li>
                                <li><a href="#6Semestre" class="tablinks">6º Semestre</a></li>
                            </ul>
                        </section>
                        <section id="ementa">
                           <h1 class="text-center">LOGÍSTICA</h1>
            	           <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lacus convallis, ornare nisl a, tristique tellus. Pellentesque gravida eu erat quis commodo. Donec et turpis viverra diam eleifend tempor. Vestibulum mattis ligula non eleifend interdum. Curabitur a lobortis lacus. Nulla nec ex vel turpis sollicitudin pharetra et eget quam. Nulla sit amet scelerisque tortor.</p>
                        </section>
                    </div>
                </div>
			  </div>
		  </div>
	   </div>
    </div>
<!-- Modal Estágio -->
	<div class="modal fade" id="Estagio" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Estagio</h1>
				</div>
				<div class="modal-body">
					                	
                </div>
            </div>
            <div class="modal-footer">
				<ul class="pager">
				    <li class="previous"><a href="#"><span aria-hidden="true">&larr;</span> Próxima Informação</a></li>
				</ul>
            </div>
        </div>
    </div>
<!-- Modal TCC -->
	<div class="modal fade" id="TrabalhoConclusao" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Trabalho de Conclusão de Curso</h1>
				</div>
				<div class="modal-body">
					                	
                </div>
				</div>
				<div class="modal-footer">
					<ul class="pager">
						<li class="previous"><a href="#"><span aria-hidden="true">&larr;</span> Próxima Informação</a></li>
					</ul>
				</div>
			</div>
    </div>
   
     <section class="container">
        <header class="banner_curso">
        	<div class="row">
            	<h1 class="text-center"><?php echo $curso->nome_curso; ?></h1>
            	<p class="text-center hidden-xs"><?php echo $curso->descricao_curso; ?></p>
            	<input type="hidden" id="idCurso" value="<?php echo $curso->id_curso; ?>" >    
                 <input type="hidden" name="_token" id="token" value="<?php echo e(Session::getToken()); ?>">
                <div class="text-center">
                  <!--  <a class="btn btn-default noticias_btn_saibamais banner_curso_button" href="#" role="button">INSCREVA-SE</a> -->
                </div>
            </div>
        </header>
    </section>
    <section class="container" role="main">
        <div class="curso_info">
        	<div class="panel panel-default hidden-xs">
                <div class="panel-heading">
                    <ul class="nav nav-tabs text-center">
                        <li><a href="#tab_sobre" data-toggle="tab">SOBRE</a></li>
                        <li><a href="#tab_corpodocente" data-toggle="tab">CORPO DOCENTE</a></li>
                        <li><a href="#tab_matrizcurricular" data-toggle="tab">MATRIZ CURRICULAR</a></li>
                        <li><a href="#tab_estagio" data-toggle="tab">ESTÁGIO</a></li>
                        <li><a href="#tab_tcc" data-toggle="tab">TCC</a></li>
                        <li><a href="#tab_faq" data-toggle="tab">FAQ</a></li>
                    </ul>
                </div>
                <div class="panel-body">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab_sobre">
                        	<div class="curso_info_sobre_content col-sm-12">
			                	<div class="col-sm-8">
				                	
				                	<h2>PROJETO PEDAGÓGICO</h2>
				                	<p ><?php echo $curso->resumo_projeto_pedagogico; ?>e</p>
                                    <div class="curso_info_sobre_content_borda"></div>
				                	<p class="text-center"><strong>DURAÇÃO:</strong> <?php echo $curso->duracao_semestres; ?> semestres</p>
				                	<p class="text-center"><strong>VAGAS:</strong> <?php echo $curso->vagas; ?></p>
				                	<p class="text-center"><strong>GRAU:</strong> Tecnológico</p>
				                	<p class="text-center wrap"><strong>MODALIDADE:</strong> <?php echo $curso->modalidade = $curso->modalidade == "P" ?  "Presencial" : "EAD"; ?></p>
				                	
				                	
			                	</div>
			                	<div class="col-sm-4 curso_info_sobre_content_coordenadora">
				                	<p class="text-center">Profº <?php echo $cordenador->nomecompleto; ?></p>
				                	<img src="<?php echo $cordenador->foto; ?>" class="img-responsive center-block" alt="Foto do coordenador do curso de <?php echo $curso->nome_curso; ?>">
				                	<p class="text-center">
                                   <?php if($cordenador->titulacao === "M"): ?>
                                       <p>Mestre</p>
                                    <?php elseif($cordenador->titulacao === "D"): ?>
                                        <p>Doutor</p>
                                    <?php else: ?>
                                        <p>Tecnólogo</p>
                                    <?php endif; ?>
                                    </p>
			                	</div>
			                </div>
                        </div>
                        <div class="tab-pane fade" id="tab_corpodocente">
                        	<div class="curso_info_corpodocente_content_sm col-sm-12">
			                    <div id="container-docentes">
                                </div>
			                	
			                	<div class="text-right">
				                    <a class="btn btn-default noticias_btn_saibamais corpodocente_button" href="#" role="button">MAIS PROFESSORES</a>
				                </div>
			                </div>
                        </div>
                        <div class="tab-pane fade" id="tab_matrizcurricular">
                        <a href="#MatrizCurricular" rel="modal" data-toggle="modal" data-target="#MatrizCurricular" style= "Color:#333">
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        1º Semestre
                                    </div>
                                </div>
                            </div>
                        <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        2º Semestre
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        3º Semestre
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        4º Semestre
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        5º Semestre
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre">
                                    <div class="div-semestre-nome">
                                        6º Semestre
                                    </div>
                                </div>
                            </div>
                        </a>
                        </div>
                        <div class="tab-pane fade" id="tab_faq">
                        	<div class="curso_info_laboratorio_content">
			                	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus a ligula non tempor. Nam tempor, neque ut viverra sollicitudin, est massa lobortis tortor, a interdum erat mi sed augue. Donec metus tellus, sagittis vel gravida vel, bibendum ac tellus. Quisque accumsan tortor neque, nec laoreet elit facilisis quis.</p>
			                	<p>Nunc ut ipsum vel felis imperdiet blandit sollicitudin eget mauris. Suspendisse lectus massa, dapibus et nisi sed, cursus pulvinar augue. Proin convallis nunc ac erat imperdiet, non laoreet nisl tempus. Integer nec quam sed est scelerisque accumsan vitae ac tellus. Cras in sem orci. Suspendisse cursus est molestie, maximus tortor eget, venenatis sapien. Suspendisse convallis blandit ipsum sit amet hendrerit. Cras cursus porttitor scelerisque. </p>
			                	<p>Pellentesque lobortis aliquam justo, at dapibus mauris. Aenean pellentesque ex a libero hendrerit, ut vulputate quam fermentum. Duis sit amet commodo diam, sit amet vehicula odio. Vestibulum finibus in quam eget viverra. Praesent enim velit, pulvinar vitae suscipit vel, consequat ac mi.</p>
			                </div>
                        </div>
                        <div class="tab-pane fade" id="tab_estagio">
                            <p>Texto sobre estágio, com descrição etc etc etc.</p>
                            <p>Nunc ut ipsum vel felis imperdiet blandit sollicitudin eget mauris. Suspendisse lectus massa, dapibus et nisi sed, cursus pulvinar augue. Proin convallis nunc ac erat imperdiet, non laoreet nisl tempus. Integer nec quam sed est scelerisque accumsan vitae ac tellus. Cras in sem orci. Suspendisse cursus est molestie, maximus tortor eget, venenatis sapien. Suspendisse convallis blandit ipsum sit amet hendrerit. Cras cursus porttitor scelerisque. </p>
                            <div class="curso_info_corpodocente_content_sm col-sm-12 text-center">
                            <a href="#Estagio" rel="modal" data-toggle="modal" data-target="#Estagio" style= "Color:#333">
                                <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>ESTÁGIO <br>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>CONVALIDAÇÃO<br>
                                        </div>
                                    </div>
                                </div>
                                
                               
                                <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>PRAZOS<br>
                                        </div>
                                    </div>
                                </div> 
                            </a>
                            </div>
                        </div>
                          <div class="tab-pane fade" id="tab_tcc"> 
                            <a href="#TrabalhoConclusao" rel="modal" data-toggle="modal" data-target="#TrabalhoConclusao" style= "Color:#333">
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                        <br><br>Trabalho <br>de graduação
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                          <br><br>Prazos de<br> entrega
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                        <br><br>Manuais e <br>modelos
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                        <br><br> Prazos após <br>apresentação
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="panel-group visible-xs" id="accordion" role="tablist" aria-multiselectable="false">
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_sobre_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_sobre_content" aria-expanded="true" aria-controls="tab_sobre_content">SOBRE</a>
			            </h4>
			        </div>
			        <div id="tab_sobre_content" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="tab_sobre_header">
			            <div class="panel-body">
			                <div class="curso_info_sobre_content col-xs-12">
			                	<p class="text-center wrap">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lacus convallis, ornare nisl a, tristique tellus. Pellentesque gravida eu erat quis commodo. Donec et turpis viverra diam eleifend tempor.</p>
			                	<p class="text-center"><strong>DURAÇÃO:</strong> 4 anos</p>
			                	<p class="text-center"><strong>VAGAS:</strong> 40</p>
			                	<p class="text-center"><strong>GRAU:</strong> Tecnológico</p>
			                	<p class="text-center wrap"><strong>MODALIDADE:</strong> Presencial</p>
			                	<p class="text-center">Prof.ª Maria de Oliveira Campos Rodrigues</p>
			                	<img src="img/foto_coordenador_logistica.jpg" class="img-responsive center-block" alt="Foto do coordenador do curso de Logística da Fatec Bebedouro.">
			                	<p class="text-center">Doutorada em Administração de Empresas pela UFSCAR</p>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_corpodocente_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_corpodocente_content" aria-expanded="true" aria-controls="tab_corpodocente_content">CORPO DOCENTE</a>
			            </h4>
			        </div>
			        <div id="tab_corpodocente_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_corpodocente_header">
			            <div class="panel-body">
			                <div class="curso_info_corpodocente_content">
			                	<img src="img/foto_professorUm.jpg" class="img-responsive center-block wrap wrap1467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorDois.jpg" class="img-responsive center-block wrap" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorTres.jpg" class="img-responsive center-block wrap wrap2467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorQuatro.jpg" class="img-responsive center-block wrap professorQuatro wrap3467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorCinco.jpg" class="img-responsive center-block wrap wrap3467 professorCinco" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorSeis.jpg" class="img-responsive center-block wrap professorSeis" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<div class="text-center">
				                    <a class="btn btn-default noticias_btn_saibamais corpodocente_button" href="#" role="button">MAIS PROFESSORES</a>
				                </div>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_matrizcurricular_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_matrizcurricular_content" aria-expanded="true" aria-controls="tab_matrizcurricular_content">MATRIZ CURRICULAR</a>
			            </h4>
			        </div>
			        <div id="tab_matrizcurricular_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_matrizcurricular_header">
			            <div class="panel-body">
                            Em desenvolvimento
                        </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_laboratorio_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_laboratorio_content" aria-expanded="true" aria-controls="tab_laboratorio_content">LABORATORIO</a>
			            </h4>
			        </div>
			        <div id="tab_laboratorio_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_laboratorio_header">
			            <div class="panel-body">
			                <div class="curso_info_laboratorio_content">
			                	<img src="img/foto_laboratorio.jpg" class="img-responsive" alt="Foto do laboratório de estudos da Fatec Bebedouro.">
			                	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus a ligula non tempor. Nam tempor, neque ut viverra sollicitudin, est massa lobortis tortor, a interdum erat mi sed augue. Donec metus tellus, sagittis vel gravida vel, bibendum ac tellus. Quisque accumsan tortor neque, nec laoreet elit facilisis quis.</p>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_estagio_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_estagio_content" aria-expanded="true" aria-controls="tab_estagio_content">ESTÁGIO</a>
			            </h4>
			        </div>
			        <div id="tab_estagio_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_estagio_header">
			            <div class="panel-body">
			                AGUARDANDO POR CONTEÚDO PARA DESENVOLVIMENTO.
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_tcc_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_tcc_content" aria-expanded="true" aria-controls="tab_tcc_content">TCC</a>
			            </h4>
			        </div>
			        <div id="tab_tcc_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_tcc_header">
			            <div class="panel-body">
			                AGUARDANDO POR CONTEÚDO PARA DESENVOLVIMENTO.
			            </div>
			        </div>
			    </div>
                </div>
                </div>
        </div>    
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>