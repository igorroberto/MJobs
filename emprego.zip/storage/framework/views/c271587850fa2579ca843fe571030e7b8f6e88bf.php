
<?php $__env->startSection('content'); ?>
	<section class="container" role="main">
    	
    	<div class="outras_noticias col-md-12">
            <?php foreach($noticias as $item): ?>
    		<div class="noticia col-md-4">
    			
            	  <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
            	  <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit nulla eu dictum nisl...</p></a>
    		</div>
    		<?php endforeach; ?>
    	</div>
		<?php echo $noticias->render(); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>