<?php $__env->startSection('content'); ?>
 <?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
var APP_URL = <?php echo json_encode(url('/')); ?>


</script>
        <script src="<?php echo asset("assets/scripts/getdocentes.js"); ?>"></script>

    <?php $__env->stopSection(); ?>
	<!-- Modal Matriz Curricular -->
	<div class="modal fade" id="MatrizCurricular" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
                <div class="partes">
                    <div class="parte1">
                        <section id="materias">
                             <a class="titulomodal">Matérias</a>
                            <ul class="tab1">

                                <li><a href="#Materia1" class="tab1links">Materia 1</a></li>

                            </ul>
                        </section>
                    </div>
                    <div class="parte2">
                        <section id="semestres">
                            <ul class="tab">
                                 <?php foreach($semestre as $item): ?>
                                <li><a href="#Semestre"  class="semestre-acao tablinks" id="<?php echo $item->id_semestre; ?>"><?php echo $item->indice; ?>º Semestre</a></li>
                                <?php endforeach; ?>
                            </ul>
                        </section>
                        <section id="ementa">
                           <h1 class="text-center titulo">Fatec Bebedouro</h1>
            	           <p class="text-center desct">Clique no menu lateral para navegar entre as disciplinas e no menu horizontal á cima para navegar entre os semestres.</p>
                        </section>
                    </div>
                </div>
			  </div>
		  </div>
	   </div>
    </div>

<!-- Modal Covalidacao -->
	<div class="modal fade" id="Covalidacao" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Informações sobre a covalidação de estágio</h1>
				</div>
				<div class="modal-body">
					    <h2>Convalidação de estágio</h2>
                    <hr>
                    <p>
A CONVALIDAÇÃO DE ESTÁGIO, também chamada de APROVEITAMENTO DE ESTÁGIO ou EQUIVALÊNCIA DE ESTÁGIO refere-se aos casos em que o aluno exerce emprego com registro em Carteira Profissional ou casos de trabalho autônomo ou de prestação de serviços devidamente regularizado junto aos órgãos competentes, desenvolvendo atividades compatíveis com o curso.<br>

Se você se enquadra nessa situação, para convalidar seu estágio, você precisará providenciar:<br>

Cópias autenticadas da sua Carteira de Trabalho:<br>
a) Página onde consta a identificação - foto do empregado (frente e verso);<br>
b) Página onde consta o contrato de trabalho (função, remuneração, etc);<br>
c) Todas as eventuais alterações no registro funcional (promoções, mudança de função, etc);<br>
Cópia da Ficha de Registro do Empregado (localizada no Livro de Registro de Empregados). Essa é uma cópia simples, não há necessidade de ser autenticada.<br>
Declaração da empresa especificando as Atividades Desenvolvidas pelo Aluno, constando a data em que o aluno foi admitido pela empresa e as atividades que ele efetivamente desenvolve durante o trabalho. Este documento deve ser em papel timbrado da empresa, com firma reconhecida do funcionário que firmou a declaração (reconhecimento de firma obrigatório) e carimbo da empresa (onde consta o CNPJ e a razão social da mesma). (Anexo 9)<br>
Solicitação de Processo de Equivalência a Estágio Supervisionado (Anexo 8), em 1 via.<br>
Relatório Final de Estágio, descrição pormenorizada de todas as atividades realizadas no período computado para estágio (240 horas), descrevendo ações, atividades desenvolvidas (bem como sua importância e pertinência), metodologias, procedimentos e outras informações relevantes. (Anexo 6)</p>

                </div>
            </div>
            <div class="modal-footer">

            </div>
        </div>
    </div>
<!-- Modal Estágio -->
	<div class="modal fade" id="Estagio" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Informações sobre o estágio</h1>
				</div>
				    <div class="modal-body">
					    <h2>Estágio</h2>
                    <hr>
                    <p>A entrega da documentação de estágio somente será permitida a partir do 4º semestre do curso, a fim de que o aluno obter os conhecimentos necessários para avaliar se realmente sua experiência é compatível com a proposta acadêmica do mesmo;<br>
A lei estabelece uma carga horária máxima. O aluno nunca poderá realizar mais do que 6 (seis) horas diárias e 30 (trinta) horas semanais.<br>
Não pode ocorrer conflito de horário de estágio com o horário das atividades acadêmicas.</p>
                    <hr>
                    <h2>Estágio obrigatório</h2>
                    <p></p>
                    <h1>Manuais e Modelos</h1>
                    <?php foreach($estagioManuais as $item): ?>
                <p>   <a href="../../../../painel\paginas\cadastros\pdf/<?php echo $item->link; ?>">  <?php echo $item->nome; ?></a></p>
                   <?php endforeach; ?>
                </div>
            </div>
            <div class="modal-footer">

            </div>
        </div>
    </div>
<!-- Modal Covalidacao -->
	<div class="modal fade" id="Prazos" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Prazos de entrega da documentação</h1>
				</div>
				<div class="modal-body">
					    <h2>Estágio</h2>
                    <hr>
                    <h4>

                      <?php foreach($estagioData as $item): ?>
                     <p><?php echo $item->data; ?></p>
                     <?php endforeach; ?>
                    </h4>

                </div>
            </div>
            <div class="modal-footer">

            </div>
        </div>
    </div>
<!-- Modal prazos -->
	<div class="modal fade" id="TrabalhoConclusaoPrazos" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Prazos para entrega do Trabalho de Conclusão de Curso</h1>
				</div>
				<div class="modal-body">
					        <h2>TCC</h2>
                    <hr>
                    <h4>

                      <?php foreach($tccDatas as $item): ?>
                      <p> Data final de entrega: <?php echo $item->dt_entfinal; ?> </p>
                      <p> Data de entrega anteprojeto: <?php echo $item->dt_fimanti; ?> </p>
                      <p> Data inicial das apresentações: <?php echo $item->dt_iniap; ?> </p>
                      <p> Data final das apresentações: <?php echo $item->dt_fimap; ?> </p><br>
                     <?php endforeach; ?>
                    </h4>

                </div>
				</div>
				<div class="modal-footer">

				</div>
			</div>
    </div>
   <!-- Modal modelos -->
	<div class="modal fade" id="TrabalhoConclusaoModelos" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">Modelos para confecção do Trabalho de Conclusão de Curso</h1>
				</div>
				<div class="modal-body">
					       <h2>TCC</h2>
                    <hr>
                    <h4>

                      <?php foreach($tccManuais as $item): ?>
                  <a href="../../../../painel\paginas\cadastros\pdf/<?php echo $item->arquivo; ?>">  <center><?php echo $item->nome; ?> </center></a>
                     <?php endforeach; ?>

                    </h4>
                </div>
				</div>
				<div class="modal-footer">
					<ul class="pager">
						<li class="previous"><a href="#"><span aria-hidden="true">&larr;</span> Próxima Informação</a></li>
					</ul>
				</div>
			</div>
    </div>

     <section class="container">
        <header class="banner_curso">
        	<div class="row">
            	<h1 class="text-center"><?php echo $curso->nome_curso; ?></h1>
            	<p class="text-center hidden-xs"><?php echo $curso->descricao_curso; ?></p>
            	<input type="hidden" id="idCurso" value="<?php echo $curso->id_curso; ?>" >
                 <input type="hidden" name="_token" id="token" value="<?php echo e(Session::getToken()); ?>">
                <div class="text-center">
                  <!--  <a class="btn btn-default noticias_btn_saibamais banner_curso_button" href="#" role="button">INSCREVA-SE</a> -->
                </div>
            </div>
        </header>
    </section>
    <section class="container" role="main">
        <div class="curso_info">
        	<div class="panel panel-default hidden-xs">
                <div class="panel-heading">
                    <ul class="nav nav-tabs text-center">
                        <li><a href="#tab_sobre" data-toggle="tab">SOBRE</a></li>
                        <li><a href="#tab_corpodocente" data-toggle="tab">CORPO DOCENTE</a></li>
                        <li><a href="#tab_matrizcurricular" data-toggle="tab">MATRIZ CURRICULAR</a></li>
                        <li><a href="#tab_estagio" data-toggle="tab">ESTÁGIO</a></li>
                        <li><a href="#tab_tcc" data-toggle="tab">TCC</a></li>
                        <li><a href="#tab_faq" data-toggle="tab">FAQ</a></li>
                    </ul>
                </div>
                <div class="panel-body">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab_sobre">
                        	<div class="curso_info_sobre_content col-sm-12">
			                	<div class="col-sm-8">

				                	<h2>PROJETO PEDAGÓGICO</h2>
				                	<p ><?php echo $curso->resumo_projeto_pedagogico; ?>e</p>
                                    <div class="curso_info_sobre_content_borda"></div>
				                	<p class="text-center"><strong>DURAÇÃO:</strong> <?php echo $curso->duracao_semestres; ?> semestres</p>
				                	<p class="text-center"><strong>VAGAS:</strong> <?php echo $curso->vagas; ?></p>
				                	<p class="text-center"><strong>GRAU:</strong> Tecnológico</p>
				                	<p class="text-center wrap"><strong>MODALIDADE:</strong> <?php echo $curso->modalidade = $curso->modalidade == "P" ?  "Presencial" : "EAD"; ?></p>


			                	</div>
			                	<div class="col-sm-4 curso_info_sobre_content_coordenadora">
				                	<p class="text-center">Profº <?php echo $cordenador->nomecompleto; ?></p>
				                	<img src="../../../../painel/fotos/docentes/<?php echo $cordenador->foto; ?>" class="img-responsive center-block" alt="Foto do coordenador do curso de <?php echo $curso->nome_curso; ?>">
				                	<p class="text-center">
                                   <?php if($cordenador->titulacao === "M"): ?>
                                       <p>Mestre</p>
                                    <?php elseif($cordenador->titulacao === "D"): ?>
                                        <p>Doutor</p>
                                    <?php else: ?>
                                        <p>Tecnólogo</p>
                                    <?php endif; ?>
                                    </p>
			                	</div>
			                </div>
                        </div>
                        <div class="tab-pane fade" id="tab_corpodocente">
                        	<div class="curso_info_corpodocente_content_sm col-sm-12">
			                    <div id="container-docentes">
                                </div>


			                </div>
                        </div>
                        <div class="tab-pane fade" id="tab_matrizcurricular">
                        <a href="#MatrizCurricular" rel="modal" data-toggle="modal" data-target="#MatrizCurricular" style= "Color:#333">
                             <?php foreach($semestre as $item): ?>
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-semestre semestre-acao" id="<?php echo $item->id_semestre; ?>">
                                    <div class="div-semestre-nome">
                                        <?php echo $item->indice; ?>º Semestre
                                    </div>
                                </div>
                            </div>
                       <?php endforeach; ?>
                        </a>
                        </div>
                     <div class="tab-pane fade" id="tab_estagio">
                            <h2>Sobre o estágio</h2>
                            <p>A regulamentação do estágio curricular supervisionado tem por finalidade estabelecer os critérios de realização e validação do estágio dos alunos do curso, bem como suas rotinas, seu processo de acompanhamento e avaliação. De acordo com a Lei nº 11.788, de 25 de setembro de 2008, estágio é o ato educativo curricular supervisionado, desenvolvido no ambiente de trabalho, que visa à preparação para o trabalho produtivo do estudante, desenvolvida sob supervisão de responsáveis, tanto por parte da empresa concedente quanto por parte da Fatec.<br>

Além de ser um requisito obrigatório para a conclusão do curso de graduação, o estágio se constitui em instrumento de integração, treinamento prático, aperfeiçoamento técnico, cultural, científico e de relacionamento humano. Também é peça importante para a qualificação profissional do aluno, pois durante sua realização ele aplicará seus conhecimentos e, consequentemente adquirirá experiências práticas, o que certamente irá enriquecer e sedimentar o aproveitamento do conteúdo teórico lhe foi oferecido durante o curso.<br>

O programa de estágio é, neste sentido, uma busca pela complementação do ensino e da aprendizagem em conformidade com o conteúdo das disciplinas. Também procura capacitar o aluno na identificação de problemas e na proposição fundamentada de soluções dentro do contexto organizacional empresarial, a partir de uma perspectiva teórico/metodológica/científica. </p>
                            <div class="curso_info_corpodocente_content_sm col-sm-12 text-center">
                            <a href="#Estagio" rel="modal" data-toggle="modal" data-target="#Estagio" style= "Color:#333">
                                <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>ESTÁGIO <br>
                                        </div>
                                    </div>
                                </div>
                                 </a>
                                   <a href="#Covalidacao" rel="modal" data-toggle="modal" data-target="#Covalidacao" style= "Color:#333">
                                 <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>COVALIDAÇÃO<br>
                                        </div>
                                    </div>
                                </div>
                                  </a>
                               <a href="#Prazos" rel="modal" data-toggle="modal" data-target="#Prazos" style= "Color:#333">
                                <div class="col-xs-2 col-sm-2 text-center">
                                    <div class="div-tcc">
                                        <div class="div-tcc-nome">
                                            <br><br>PRAZOS<br>
                                        </div>
                                    </div>
                                </div>
                             </a>
                            </div>
                        </div>
                          <div class="tab-pane fade" id="tab_tcc">
                             <h2> Sobre o trabalho de graduação</h2>
Um trabalho de conclusão de curso de graduação é uma etapa obrigatória para o término do curso, muito importante no âmbito acadêmico. Ele se constitui de um trabalho único, com conteúdo aprofundado, capaz de mostrar problemas e apresentar soluções, como também o desenvolvimento de novas abordagens, a fim de contribuir para o desenvolvimento e crescimento da área estudada, da profissão escolhida e do nível de conhecimentos teóricos e práticos do aluno.<br><br>

Ao término da elaboração do trabalho de conclusão, o aluno realizará a exposição através de uma arguição a uma banca de professores, expondo as motivações para elaboração de seu trabalho, seu processo de pesquisa e seus resultados.<br><br>

O aluno deverá expor um pôster sobre seu trabalho à comunidade acadêmica (conforme Manuais e Modelos), durante o período em que sua arguição for agendada.<br><br>

Após a arguição, o professor orientador deverá entregar ao aluno as cópias dos membros da banca, para que possa realizar as correções necessárias.<br><br>

<h2>Prazos após apresentação</h2>
Depois de apresentar seu trabalho, o aluno tem 30 dias de prazo para providenciar as correções sugeridas pelos professores membros da banca. Transcorrido esse período, o aluno:<br><br>

Deverá imprimir uma cópia do trabalho de graduação em modo econômico, sem encadernação;<br>
Dirigir-se à Coordenação de Cursos para preencher o Requerimento para a última fase do processo de avaliação do trabalho.<br>
                            <a href="#TrabalhoConclusaoPrazos" rel="modal" data-toggle="modal" data-target="#TrabalhoConclusaoPrazos" style= "Color:#333">

                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                          <br><br>Prazos de<br> entrega
                                    </div>
                                </div>
                            </div>
                                 </a>
                               <a href="#TrabalhoConclusaoModelos" rel="modal" data-toggle="modal" data-target="#TrabalhoConclusaoModelos" style= "Color:#333">
                            <div class="col-xs-2 col-sm-2 text-center">
                                <div class="div-tcc">
                                    <div class="div-tcc-nome">
                                        <br><br>Manuais e <br>modelos
                                    </div>
                                </div>
                            </div>
                             </a>

                        </div>
                           <div class="tab-pane fade" id="tab_faq">
                             <h2> Perguntas frequentes</h2>

  <div class="list-group panel">
   <?php foreach($faq as $item): ?>
    <a href="#demo<?php echo $item->id_faq; ?>" class="list-group-item " data-toggle="collapse" data-parent="#MainMenu"><?php echo $item->pergunta; ?></a>
    <div class="collapse" id="demo<?php echo $item->id_faq; ?>">
      <div class="list-group-item"><?php echo $item->resposta; ?></div>

    </div>
       <?php endforeach; ?>
  </div>


Caso tenha mais alguma dúvida, por favor entre em contato pelo e-mail: contato@fatecbb.edu.br<br>


                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="panel-group visible-xs" id="accordion" role="tablist" aria-multiselectable="false">
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_sobre_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_sobre_content" aria-expanded="true" aria-controls="tab_sobre_content">SOBRE</a>
			            </h4>
			        </div>
			        <div id="tab_sobre_content" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="tab_sobre_header">
			            <div class="panel-body">
			                <div class="curso_info_sobre_content col-xs-12">
			                	<p class="text-center wrap">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lacus convallis, ornare nisl a, tristique tellus. Pellentesque gravida eu erat quis commodo. Donec et turpis viverra diam eleifend tempor.</p>
			                	<p class="text-center"><strong>DURAÇÃO:</strong> 4 anos</p>
			                	<p class="text-center"><strong>VAGAS:</strong> 40</p>
			                	<p class="text-center"><strong>GRAU:</strong> Tecnológico</p>
			                	<p class="text-center wrap"><strong>MODALIDADE:</strong> Presencial</p>
			                	<p class="text-center">Prof.ª Maria de Oliveira Campos Rodrigues</p>
			                	<img src="img/foto_coordenador_logistica.jpg" class="img-responsive center-block" alt="Foto do coordenador do curso de Logística da Fatec Bebedouro.">
			                	<p class="text-center">Doutorada em Administração de Empresas pela UFSCAR</p>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_corpodocente_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_corpodocente_content" aria-expanded="true" aria-controls="tab_corpodocente_content">CORPO DOCENTE</a>
			            </h4>
			        </div>
			        <div id="tab_corpodocente_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_corpodocente_header">
			            <div class="panel-body">
			                <div class="curso_info_corpodocente_content">
			                	<img src="img/foto_professorUm.jpg" class="img-responsive center-block wrap wrap1467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorDois.jpg" class="img-responsive center-block wrap" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorTres.jpg" class="img-responsive center-block wrap wrap2467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorQuatro.jpg" class="img-responsive center-block wrap professorQuatro wrap3467" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorCinco.jpg" class="img-responsive center-block wrap wrap3467 professorCinco" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<img src="img/foto_professorSeis.jpg" class="img-responsive center-block wrap professorSeis" alt="Foto de um(a) professor(a) do curso de Logística da Fatec Bebedouro.">
			                	<div class="text-center">
				                    <a class="btn btn-default noticias_btn_saibamais corpodocente_button" href="#" role="button">MAIS PROFESSORES</a>
				                </div>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_matrizcurricular_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_matrizcurricular_content" aria-expanded="true" aria-controls="tab_matrizcurricular_content">MATRIZ CURRICULAR</a>
			            </h4>
			        </div>
			        <div id="tab_matrizcurricular_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_matrizcurricular_header">
			            <div class="panel-body">
                            Em desenvolvimento
                        </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_laboratorio_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_laboratorio_content" aria-expanded="true" aria-controls="tab_laboratorio_content">LABORATORIO</a>
			            </h4>
			        </div>
			        <div id="tab_laboratorio_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_laboratorio_header">
			            <div class="panel-body">
			                <div class="curso_info_laboratorio_content">
			                	<img src="img/foto_laboratorio.jpg" class="img-responsive" alt="Foto do laboratório de estudos da Fatec Bebedouro.">
			                	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse luctus a ligula non tempor. Nam tempor, neque ut viverra sollicitudin, est massa lobortis tortor, a interdum erat mi sed augue. Donec metus tellus, sagittis vel gravida vel, bibendum ac tellus. Quisque accumsan tortor neque, nec laoreet elit facilisis quis.</p>
			                </div>
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_estagio_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_estagio_content" aria-expanded="true" aria-controls="tab_estagio_content">ESTÁGIO</a>
			            </h4>
			        </div>
			        <div id="tab_estagio_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_estagio_header">
			            <div class="panel-body">
			                AGUARDANDO POR CONTEÚDO PARA DESENVOLVIMENTO.
			            </div>
			        </div>
			    </div>
			    <div class="panel panel-default">
			        <div class="panel-heading" role="tab" id="tab_tcc_header">
			            <h4 class="panel-title">
			                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#tab_tcc_content" aria-expanded="true" aria-controls="tab_tcc_content">TCC</a>
			            </h4>
			        </div>
			        <div id="tab_tcc_content" class="panel-collapse collapse" role="tabpanel" aria-labelledby="tab_tcc_header">
			            <div class="panel-body">
			                AGUARDANDO POR CONTEÚDO PARA DESENVOLVIMENTO.
			            </div>
			        </div>
			    </div>
                </div>
                </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>