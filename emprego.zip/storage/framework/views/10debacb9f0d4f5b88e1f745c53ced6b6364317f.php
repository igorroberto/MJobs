<?php $__env->startSection('content'); ?>
	<!-- Modal -->
	 <?php  $f = $item  =null;  $j=0; error_reporting(0); ?>
     <?php for($i=0; $i < count($noticias); $i++): ?>
 <?php

                                       if($i == 0){

                                       $item = $noticias[$i];
                                       }elseif($i > 0 && $i <=2 ){

                                        $noticiaSub[$f] = $noticias[$i];
                                       $f++;
                                       }elseif($i > 2 && $i <= 5){

                                        $noticiaModal[$j] = $noticias[$i];
                                      $j++;
                                       }
                                       ?>
<?php endfor; ?>

    <section class="container" role="main">
        <div class="noticias">
            <header class="row">
                <h1 class="col-md-12 text-center">NOTÍCIAS</h1>
            </header>
            <div class="row">
                <div class="col-md-6 col-sm-6 noticias_principal" style="background-image: url(../painel/fotos/noticias/<?php echo $item->foto; ?>);">
                    	<a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
                    <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                        <span class="dia">21</span>
                        <span class="mes_ano"><p>NOV<br/>2015</p></span>
                    </div>
                    <div class="noticias_link noticia-principal">
                       <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
                        <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p><?php echo $item->previa; ?>...</p></a>

            		</div>
                </div>
                <div class="modal fade" id="MaisNoticias" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h1 class="modal-title text-center" id="myModalLabel">NOTÍCIAS</h1>
				</div>
				<div class="modal-body">

                     <?php foreach($noticiaModal as $item): ?>



                      <div class="noticias_modal">
	                <a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
	                    <div class="noticias_link">
	                     <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>
	                       <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu dictum nisl. Sed gravida est euismod dui faucibus, eu aliquam tellus tincidunt. Nullam id egestas massa, a ultrices risus...</p></a>
	                    </div>
                	</div>

                     <?php endforeach; ?>
				</div>



				<div class="modal-footer">
					<ul class="pager">
						<li class="previous"><a href="<?php echo URL::to('/noticia/noticias/');; ?>"><span aria-hidden="true">&larr;</span> MAIS ANTIGAS</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
                 <?php foreach($noticiaSub as $item): ?>


                       <div class="col-md-6 col-sm-6 noticias_secundaria noticias_secundariaUm">
                           <a href="<?php echo URL::to('/noticia/categoria/');; ?>/<?php echo $item->categoria->linkCategoria; ?>/<?php echo $item->categoria->codigo; ?>"><button class="btn btn-default" type="submit"><?php echo $item->categoria->descricao; ?></button></a>
                            <div class="noticias_data hidden-xs hidden-sm hidden-md hidden-lg">
                                <span class="dia">21</span>
                                <span class="mes_ano"><p>NOV<br/>2015</p></span>
                            </div>
                            <div class="noticias_link">
                                <a href="<?php echo URL::to('/noticia/e/');; ?>/<?php echo $item->linkNoticia;; ?>/<?php echo $item->id_noticia;; ?>"><h1><?php echo $item->titulo; ?></h1></a>

                            </div>
                        </div>
                <?php endforeach; ?>


                <div class="text-right">
                    <button type="button" class="btn btn-default noticias_btn_saibamais notop" data-toggle="modal" data-target="#MaisNoticias">MAIS NOTÍCIAS</button>
                </div>
            </div>
        </div>
    </section>
    <section class="container">
        <div class="sobre">
            <header class="row">
                <h1 class="col-md-12 text-center">SOBRE</h1>
            </header>
            <div class="row sobre_conteudo">
                <div class="col-md-6 sobre_contTexto hidden-lg">
                    <p>.</p>
                </div>
                <div class="col-md-6 sobre_contTexto visible-lg">
                   <p>A <b>Faculdade de Tecnologia de Bebedouro</b> é uma das 65 Unidades que oferecem Cursos Superiores de Graduação Tecnológica do Centro Estadual de Educação Tecnológica Paula Souza. Criada em 2014, oferece atualmente o Curso Superior de Tecnologia em Logística de forma gratuita. Neste semestre ingressaram 40 alunos da terceira turma. Situada na cidade de Bebedouro, no interior do Estado de São Paulo, que é considerada a Capital Nacional da Laranja, atualmente busca ser também a Capital Nacional da Logística pela instalação de diversas empresas deste setor na cidade. Este foi um dos motivos determinantes para que a FATEC trouxesse para Bebedouro o Curso Superior de Tecnologia em Logística.</p>
                    <p>A partir de 22 de abril de 2015 através da Lei 15.816/15, a Faculdade de Tecnologia de Bebedouro passa a denominar-se “Jorge Caram Sabbag”, proposta sob o projeto de Lei 569/2014 de autoria do Deputado Estadual Roberto Engler. A homenagem ao comerciante falecido em 2010, uma das figuras mais tradicionais da sociedade bebedourense dos últimos anos, foi motivada especialmente pelo seu trabalho como fundador e grande incentivador da Patrulha Ecológica.</p>
                </div>
                <div class="col-md-6 sobre_contImg">
                    <img src="<?php echo asset("assets/img/fatec_frente.jpg"); ?>" class="img-responsive" alt="Foto do Campus da Fatec Bebedouro">
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>