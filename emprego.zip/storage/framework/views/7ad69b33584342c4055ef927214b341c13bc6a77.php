<h1>Painel login fatec bb </h1>
<?php $__empty_1 = true; foreach($carros as $carro): $__empty_1 = false; ?>
<p>Nome <?php echo e($carro->nome); ?></p>

<?php endforeach; if ($__empty_1): ?>
<p>nenhum carro</p>
<?php endif; ?>