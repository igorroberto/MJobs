<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Email extends Model
{
    //
    private $nome ;
    private $email;
    private $assunto;
    private $mensagem;
  
}
