<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CursoDocente extends Model
{
    //
    protected $table = "curso_docente";
    protected $primaryKey = "codigo";

  
}
