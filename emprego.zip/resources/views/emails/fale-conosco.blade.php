<!DOCTYPE html>
    <html lang="pt-br">
      <head>
        <meta charset="utf-8">
      </head>
      <body>
        <h2>Dados do contato</h2>
        <p>Nome: {{ $nome }}</p>
        <p>E-mail: {{ $email }}</p>
        <p>Assunto: {{ $assunto }}</p>
         <p>Mensagem: {{ $mensagem }}</p>
      </body>
    </html>
  