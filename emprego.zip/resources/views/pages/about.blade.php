@extends('layout.default')
@section('content')
	this is my about page
@stop