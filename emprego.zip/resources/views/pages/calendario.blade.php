@extends('layout.default')
@section('content')
	<section class="container" role="main">
    	
    	<div class="sobre">
           
<object class="pdf" data="../calendario/Matriz_Logistica.pdf" type="application/pdf" internalinstanceid="14" style="min-width: 100%; min-height: 800px;" title="">Seu browser não suporta PDF</object>
        </div>
    </section>
@stop